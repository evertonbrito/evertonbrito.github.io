"""Convert Heiko Schulz's GPL EC135 AC3D assets to an authoring-only GLB.
Run in Blender: blender -b -P scripts/convert-ec135.py -- /path/to/ec135
Original geometry and UVs are retained; only equipment alternatives are selected.
"""
import bpy,sys,shlex,re,math
from pathlib import Path
from mathutils import Matrix
root=Path(sys.argv[sys.argv.index('--')+1]); out=Path.cwd()/'public/authoring/ec135.glb'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
conversion=Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)))
exclude={'BigRadom','DoubleCargoHook','EmergFloats','Loudspeaker','highskid','longskid_floats','lowskid','nonIBF','nosefl','sandfilter','smallradom','snowboard_highskid','snowboard_lowskid','snowboard_midskid','roundstep','triangle','wirecutter_highskid','rotor_disc_T','windscreen_tri'}
materials={}
def read_ac(path,offset=(0,0,0),parent=None,rotor=False):
 lines=path.read_text(errors='replace').splitlines(); i=1;mats=[]
 while i<len(lines) and lines[i].startswith('MATERIAL'):
  a=shlex.split(lines[i]); prop=lambda k,n:tuple(map(float,a[a.index(k)+1:a.index(k)+1+n]));mats.append((a[1],prop('rgb',3),prop('trans',1)[0]));i+=1
 def parse(parent=None):
  nonlocal i
  kind=lines[i].split()[1];i+=1;name=kind;tex=None;verts=[];faces=[];uvs=[];mis=[];loc=(0,0,0);rotation=None
  while i<len(lines):
   s=lines[i];i+=1
   if s.startswith('name '):name=shlex.split(s)[1]
   elif s.startswith('data '):i+=1
   elif s.startswith('texture '):tex=shlex.split(s)[1]
   elif s.startswith('loc '):loc=tuple(map(float,s.split()[1:]))
   elif s.startswith('rot '):a=list(map(float,s.split()[1:]));rotation=Matrix([a[j:j+3]for j in (0,3,6)]).to_4x4()
   elif s.startswith('numvert '):
    n=int(s.split()[1]);verts=[tuple(map(float,l.split()))for l in lines[i:i+n]];i+=n
   elif s.startswith('numsurf '):
    n=int(s.split()[1])
    for _ in range(n):
     mi=0;flag=0
     while not lines[i].startswith('refs '):
      if lines[i].startswith('mat '):mi=int(lines[i].split()[1])
      if lines[i].startswith('SURF '):flag=int(lines[i].split()[1],0)
      i+=1
     count=int(lines[i].split()[1]);i+=1;refs=[l.split()for l in lines[i:i+count]];i+=count
     if flag&0xf==0 and count>=3:faces.append([int(r[0])for r in refs]);uvs.append([tuple(map(float,r[1:3]))for r in refs]);mis.append(mi)
   elif s.startswith('kids '):
    kids=int(s.split()[1]);break
  visible=name not in exclude and not any(x in name for x in ['.flare','.glare','navlight','Plane.00','strobes'])
  if rotor and (name.startswith('blurred')or name=='blade1.002'):visible=False
  if faces and visible:
   mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();obj=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(obj)
   uv=mesh.uv_layers.new(name='UVMap')
   for poly,coords,mi in zip(mesh.polygons,uvs,mis):
    poly.use_smooth=True
    for li,p in zip(poly.loop_indices,coords):uv.data[li].uv=p
   slots={}
   for mi in set(mis):
    mn,rgb,trans=mats[mi];key=(str(path.parent),mn,tex)
    if key not in materials:
     mat=bpy.data.materials.new(mn);mat.use_nodes=True;bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*rgb,1);bs.inputs['Roughness'].default_value=.48;bs.inputs['Metallic'].default_value=.2
     if 'glas' in mn.lower():bs.inputs['Base Color'].default_value=(.018,.045,.06,1);bs.inputs['Metallic'].default_value=.65;bs.inputs['Roughness'].default_value=.2
     if tex and (path.parent/tex).exists():
      image=bpy.data.images.load(str(path.parent/tex),check_existing=True);node=mat.node_tree.nodes.new('ShaderNodeTexImage');node.image=image;mat.node_tree.links.new(node.outputs['Color'],bs.inputs['Base Color'])
     materials[key]=mat
    slots[mi]=len(mesh.materials);mesh.materials.append(materials[key])
   for p,mi in zip(mesh.polygons,mis):p.material_index=slots[mi]
  else:
   obj=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(obj)
  if parent:obj.parent=parent
  obj.location=loc
  if rotation:obj.matrix_basis=Matrix.Translation(loc)@rotation
  for _ in range(kids):parse(obj)
  return obj
 obj=parse(parent);obj.location=offset
 return obj
base=read_ac(root/'Models/ec135.ac');base.matrix_world=conversion
rot=read_ac(root/'Models/rotors/mainrotor.ac',offset=(3.023,1.801,0),parent=base,rotor=True);rot.name='main_rotor'
# The cockpit/interior are source geometry too, rather than blank windows.
inside=read_ac(root/'Models/interior.ac',parent=base)
for o in bpy.context.scene.objects:
 if o.type=='MESH':
  # AC3D objects carry their own hard edges; preserve UVs, smooth normals only.
  o.data.validate()
bpy.ops.wm.save_as_mainfile(filepath=str(Path.cwd()/'assets/recovery-source/ec135.blend'))
bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',export_yup=True,export_animations=False)
print('Exported EC135',out)
